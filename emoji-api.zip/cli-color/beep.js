'use strict';

module.exports = '\x07';
