'use strict';

module.exports = '\x1b[2J\x1b[0;0H';
