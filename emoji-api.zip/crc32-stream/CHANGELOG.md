## Changelog

**3.0.1** — <small>_August 2, 2019_</small> — [Diff](https://github.com/archiverjs/node-crc32-stream/compare/3.0.0...3.0.1)

- update dependencies

**3.0.0** — <small>_April 29, 2019_</small> — [Diff](https://github.com/archiverjs/node-crc32-stream/compare/2.0.0...3.0.0)

- Require Node.js 6.9, update dependencies, use modern JS syntax (GH #10)
- Do not use the deprecated Buffer() constructor (GH #8)
- remove node v0.10 and v0.12 support

**2.0.0** — <small>_February 13, 2017_</small> — [Diff](https://github.com/archiverjs/node-crc32-stream/compare/1.0.1...2.0.0)

- adopt nodejs core Hash API (GH #4)

**1.0.1** — <small>_January 12, 2016_</small> — [Diff](https://github.com/archiverjs/node-crc32-stream/compare/1.0.0...1.0.1)

- Switch to node-crc for performance (GH #3)
- bump deps to ensure latest versions are used.

[Release Archive](https://github.com/archiverjs/node-crc32-stream/releases)
