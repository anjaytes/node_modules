/**
 * Aliases are pseudos that are expressed as selectors.
 */
export declare const aliases: Record<string, string>;
//# sourceMappingURL=aliases.d.ts.map