# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [1.0.1](https://github.com/medikoo/d/compare/v0.1.1...v1.0.1) (2019-06-14)

## Changelog for previous versions

See `CHANGES` file
