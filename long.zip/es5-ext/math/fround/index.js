"use strict";

module.exports = require("./is-implemented")() ? Math.fround : require("./shim");
