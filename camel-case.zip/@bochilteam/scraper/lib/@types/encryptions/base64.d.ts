export declare function toBase64(data: any): string;
export declare function fromBase64ToString(data: string): string;
//# sourceMappingURL=base64.d.ts.map