import { Family100 } from './types';
export declare let family100json: Family100[];
export default function family100(): Promise<Family100>;
//# sourceMappingURL=family100.d.ts.map