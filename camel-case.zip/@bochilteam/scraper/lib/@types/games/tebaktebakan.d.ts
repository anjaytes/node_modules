import { TebakTebakan } from './types';
export declare let tebaktebakanjson: TebakTebakan[];
export default function tebaktebakan(): Promise<TebakTebakan>;
//# sourceMappingURL=tebaktebakan.d.ts.map