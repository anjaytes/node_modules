import { TebakKata } from './types';
export declare let tebakkatajson: TebakKata[];
export default function tebakkata(): Promise<TebakKata>;
//# sourceMappingURL=tebakkata.d.ts.map