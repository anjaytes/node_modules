import { SiapakahAku } from './types';
export declare let siapakahakujson: SiapakahAku[];
export default function siapakahaku(): Promise<SiapakahAku>;
//# sourceMappingURL=siapakahaku.d.ts.map