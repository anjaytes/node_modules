import { TebakKabupaten } from './types';
export declare let tebakkabupatenjson: TebakKabupaten[];
export default function tebakkabupaten(): Promise<TebakKabupaten>;
//# sourceMappingURL=tebakkabupaten.d.ts.map