import { TekaTeki } from './types';
export declare let tekatekijson: TekaTeki[];
export default function tekateki(): Promise<TekaTeki>;
//# sourceMappingURL=tekateki.d.ts.map