export { default as wikipedia } from './wikipedia.js';
export { default as jadwalTV, jadwalTVNow, listJadwalTV } from './jadwal-tv.js';
export { default as kbbi } from './KBBI.js';
export { default as nameFreeFire } from './idff.js';
export { default as zippyshare } from './zippyshare.js';
export * from './minecraft.js';
export * from './mediafire.js';
export * from './BMKG.js';
export * from './lyrics.js';
export * from './minecraft.js';
export * from './bioskop.js';
export * from './chord.js';
//# sourceMappingURL=index.d.ts.map