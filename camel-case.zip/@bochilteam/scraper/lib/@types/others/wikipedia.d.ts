import { Wikipedia } from './types.js';
export default function wikipedia(query: string, lang?: 'en' | 'id'): Promise<Wikipedia>;
//# sourceMappingURL=wikipedia.d.ts.map