import { NameFreeFire } from './types.js';
export default function nameFreeFire(id: string | number): Promise<NameFreeFire>;
//# sourceMappingURL=idff.d.ts.map