import { ZippyShare } from './types.js';
export default function zippyshare(url: string): Promise<ZippyShare>;
//# sourceMappingURL=zippyshare.d.ts.map