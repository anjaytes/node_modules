import { Gempa, GempaNow, Tsunami } from './types.js';
export declare function gempa(): Promise<Gempa[]>;
export declare function gempaNow(): Promise<GempaNow[]>;
export declare function tsunami(): Promise<Tsunami[]>;
//# sourceMappingURL=BMKG.d.ts.map