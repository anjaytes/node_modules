import { Chord } from './types.js';
export declare function chord(query: string): Promise<Chord>;
//# sourceMappingURL=chord.d.ts.map