import { Mediafire } from './types.js';
export declare function mediafiredl(url: string): Promise<Mediafire>;
//# sourceMappingURL=mediafire.d.ts.map