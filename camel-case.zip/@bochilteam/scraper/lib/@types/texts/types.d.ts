export interface TextProList {
    link: string;
    title: string;
    parameters: boolean[];
}
//# sourceMappingURL=types.d.ts.map