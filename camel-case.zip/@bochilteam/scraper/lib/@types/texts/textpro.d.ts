import type { TextProList } from './types';
export declare const textproList: Promise<TextProList[]>;
export default function textpro(effect: string, params: string[] | string): Promise<string>;
//# sourceMappingURL=textpro.d.ts.map