export declare let truthjson: string[];
export default function truth(): Promise<string>;
//# sourceMappingURL=truth.d.ts.map