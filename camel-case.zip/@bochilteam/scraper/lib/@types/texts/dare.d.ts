export declare let darejson: string[];
export default function dare(): Promise<string>;
//# sourceMappingURL=dare.d.ts.map