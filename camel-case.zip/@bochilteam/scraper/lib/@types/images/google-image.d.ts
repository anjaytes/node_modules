export default function googleImage(query: string): Promise<string[]>;
//# sourceMappingURL=google-image.d.ts.map