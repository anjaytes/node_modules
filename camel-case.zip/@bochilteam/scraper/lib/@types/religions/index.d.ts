export { default as asmaulhusna, asmaulhusnajson } from './asmaulhusna.js';
export { default as jadwalsholat, listJadwalSholat } from './jadwalsholat.js';
export * from './alquran.js';
//# sourceMappingURL=index.d.ts.map