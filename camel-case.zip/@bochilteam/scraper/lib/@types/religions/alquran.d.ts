import { AlQuran } from './types.js';
export declare function alquran(): Promise<AlQuran[]>;
//# sourceMappingURL=alquran.d.ts.map