import { JadwalSholat, JadwalSholatItem } from './types.js';
export declare const listJadwalSholat: Promise<JadwalSholatItem[]>;
export default function jadwalsholat(kota: string): Promise<JadwalSholat>;
//# sourceMappingURL=jadwalsholat.d.ts.map