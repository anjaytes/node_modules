export { default as didyoumean } from './didyoumean.js';
//# sourceMappingURL=index.d.ts.map