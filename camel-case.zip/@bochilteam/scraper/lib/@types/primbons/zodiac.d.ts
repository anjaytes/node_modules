import { Zodiac } from './types';
export default function getZodiac(months: number, dates: number): Zodiac;
//# sourceMappingURL=zodiac.d.ts.map