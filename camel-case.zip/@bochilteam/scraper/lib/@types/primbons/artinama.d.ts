export default function artinama(nama: string): Promise<string>;
//# sourceMappingURL=artinama.d.ts.map