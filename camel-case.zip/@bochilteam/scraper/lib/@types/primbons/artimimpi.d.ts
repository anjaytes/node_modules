export default function artimimpi(mimpi: string): Promise<string[]>;
//# sourceMappingURL=artimimpi.d.ts.map