import type { Kompas } from './types';
export default function kompas(): Promise<Kompas[]>;
//# sourceMappingURL=kompas.d.ts.map