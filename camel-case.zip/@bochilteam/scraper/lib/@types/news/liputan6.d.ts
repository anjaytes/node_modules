import type { Liputan6 } from './types';
export default function liputan6(): Promise<Liputan6[]>;
//# sourceMappingURL=liputan6.d.ts.map