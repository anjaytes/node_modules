import cnbindonesia from './cnbcindonesia.js';
import antaranews from './antaranews.js';
import kompas from './kompas.js';
import suaracom from './suaracom.js';
import liputan6 from './liputan6.js';
import merdeka from './merdeka.js';
export { cnbindonesia, antaranews, kompas, suaracom, liputan6, merdeka };
//# sourceMappingURL=index.d.ts.map