import type { Antaranews } from './types';
export default function antaranews(): Promise<Antaranews[]>;
//# sourceMappingURL=antaranews.d.ts.map