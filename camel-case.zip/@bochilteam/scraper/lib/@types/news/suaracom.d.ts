import type { Suaracom } from './types';
export default function suaracom(): Promise<Suaracom[]>;
//# sourceMappingURL=suaracom.d.ts.map