import { Aiovideodl } from './types.js';
export default function aiovideodl(url: string): Promise<Aiovideodl>;
//# sourceMappingURL=aiovideodl.d.ts.map