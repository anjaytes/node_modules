import { SnapSave } from './types.js';
export default function snapsave(url: string): Promise<SnapSave[]>;
//# sourceMappingURL=snapsave.d.ts.map