import { GroupWA } from './types.js';
export declare function groupWA(query: string): Promise<GroupWA[]>;
//# sourceMappingURL=groupWA.d.ts.map