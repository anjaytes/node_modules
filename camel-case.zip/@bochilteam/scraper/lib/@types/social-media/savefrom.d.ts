import { Savefrom } from './types.js';
export default function savefrom(url: string): Promise<Savefrom[]>;
//# sourceMappingURL=savefrom.d.ts.map