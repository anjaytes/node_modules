import { GoogleIt } from './types.js';
export declare function googleIt(query: string): Promise<GoogleIt>;
//# sourceMappingURL=google-it.d.ts.map