import { TwitterDownloader, TwitterDownloaderV2 } from './types.js';
export declare function twitterdl(url: string): Promise<TwitterDownloader[] | []>;
export declare function twitterdlv2(url: string): Promise<TwitterDownloaderV2[]>;
//# sourceMappingURL=twitter.d.ts.map